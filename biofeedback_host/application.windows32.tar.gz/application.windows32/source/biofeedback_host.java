import processing.core.*; 
import processing.data.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class biofeedback_host extends PApplet {

/*
 *  biofeedback_host v0.3
 *  tested with Processing 1.5.1 
 *  brentAthorne <at> gmail.com
 *  5 Nov 2012  first release
 *  19 Dec 2012 added simple dt' waveform
 *  12 Jan 2013 added automatic serial port selection and muscle map
 */

    

PrintWriter output;  //file writer
Serial myPort;       //serial port            
PFont myFont;        //some font
PFont muscleFont;

int   buffer[][];        //buffer pointer
int   s=0;
float samplePeriod = 5000;
float myScale = 1.0f/(samplePeriod);

boolean serialConnected = false;
float gradulation = 500.0f; //500ms
boolean recording = false;

int focus = 0;  //0 is button focus, 1 is map focus

public void setup() {  
  size(800, 640);
  setupFont();

  //data buffer
  buffer= new int[width][2]; // create buffer; [][0] is sample , [][1] is y

  //zero buffer
  for (int i=0; i<width; i++) {
    buffer[i][0]=0;
    buffer[i][1]=height/2;
  }

  //connect serial
  if ( establishSerialConnection()) {
    println("Serial connection established.");
  } 
  else exit();
  setupMuscleMap();
}

public void draw() {
  //drawMuscleMap();
  if (focus == 0) {
    textFont(myFont);
    background(0);
    drawGraph();
    drawButtons();
  }
  if (focus == 1) {
    textFont(muscleFont);
    drawMuscleMap();
  }
}

public void drawButtons() {
  stroke(0, 255, 0);
  strokeWeight(1);
  fill(0, 255, 0);

  /*
  text("<SPACE> start/stop recording", 10, 30);
   text("<S> screenshot", 10, 50);
   */
  if (recording) 
    text("RECORDING...", width - 100, 30);

  //record button
  if (!recording) {
    if (dist(mouseX, mouseY, width - 190, 50)< 30)
      fill(0, 255, 0);
    else
      fill(255, 0, 0);
    rect(width - 200, 30, 10, 30);
    rect(width - 180, 30, 10, 30);
    text("Press to Record", width - 160, 50);
  } 
  else {
    if (dist(mouseX, mouseY, width - 190, 50)< 30)
      fill(0, 255, 0);
    else
      fill(255, 0, 0);
    rect(width - 200, 30, 30, 30);
    text("Press to Stop Recording", width - 160, 50);
  }

  //muscle button

  if (dist(mouseX, mouseY, 50, 45)< 30)
    fill(0, 255, 0);
  else
    fill(255, 0, 0);
  ellipse(50, 45, 30, 30);
  text("Press to Select Muscle", 80, 50);
  String s = "Muscle Group: ";
  s+= getActiveMuscle();
  text(s, 45, 80);
}

public void mousePressed() {
  if (focus == 0) {
    if (dist(mouseX, mouseY, width - 190, 50)< 30) {//record button
      if (recording)
         stopRecording();
      else
        startRecording();
    }

    if (dist(mouseX, mouseY, 50, 40)< 30) { //muslce selection button
      focus = 1;
      recording = false;
    }
  }
  if (focus == 1) 
    mapFoucedMousePressed();
}

public void drawGraph() {
  float t=0.0001f;

  noFill();
  fill(0, 255, 0);

  String message = "Scale ";
  message += gradulation;
  message += " ms";
  text(message, width - 100, height-30);


  //screen width/scale_in_microseconds = microsecond per screen
  int ms = PApplet.parseInt(gradulation*width*myScale);

  stroke(0, 55, 0);
  for (int i = 0; i< width; i+=ms)
    line(i, 0, i, height); 


  for (int i=2; i<width; i++) {
    //display v/dt
    stroke(0, 255, 0);
    line ( t*myScale, map(buffer[i-1][1], 0, 1023, height, 0), 
    (t+buffer[i][0])*myScale, map(buffer[i][1], 0, 1023, height, 0 ));

    //display v/dt'
    stroke(255, 255, 0);
    line ( t*myScale, map( (buffer[i-1][1] - buffer[i-2][1]), 0, 1023, height-50, height- height/2), 
    (t+buffer[i][0])*myScale, map( (buffer[i][1]- buffer[i-1][1]), 0, 1023, height-50, height-height/2 ));

    //update time    
    t+=buffer[i][0];

    if (s==i) {
      stroke(255, 0, 0);
      line (t*myScale, 0, t*myScale, height);
      stroke(0, 255, 0);
    }
  }
}

public void serialEvent(Serial myPort) { 

  if (!serialConnected) {
    disconnectedSerialEvent(myPort);
    return;
  }

  String myString;
  myPort.write("A");
  myString = myPort.readStringUntil('\n');

  myString = trim(myString);
  int nums[] = PApplet.parseInt(split(myString, ','));
  for (int i=0; i < nums.length; i++) {
    print(nums[i]);
    print(":");
  }

  if (nums.length == 2) {
    buffer[s][0]=nums[0];
    buffer[s][1]=nums[1];
    s++;
    if (s >=width) {
      s=0;
       if (recording) 
             output.println( nums[0] + "," + nums[1] );
/*
      if (recording) {
        for (int i=0; i<width; i++) {
            output.println( buffer[i][0] + "," + buffer[i][1] );
        }
      }
      */
    }
  }
  println();
}

public void setupFont() {
  //String[] fontList = PFont.list();
  //println(fontList);
  myFont = createFont("Free Sans", 12);
  muscleFont = createFont("Free Sans", 20);
  textFont(myFont);
}


public void keyPressed() {
  int k=key;
  println   (k);

  //record
  if (k == PApplet.parseInt(' ') || k == PApplet.parseInt('R') || k == PApplet.parseInt('r')) {
    if (recording)  //close file
      stopRecording();
    else
      startRecording();

    if  (k == PApplet.parseInt('M') || k == PApplet.parseInt('m'))
      focus = 1;

    if (k == 's' || k == 'S')
      saveFrame("screenShot###.jpg");  //fix name
  }
}

public void startRecording() {
  
      String s= "M_" + year() + '_' + month() + '_' + day() + "__" + hour() + '_' + minute() + '_' + second() + '_';
       s+= getActiveMuscle();
      output = createWriter(s);  //fix name
      recording = true;
}

public void stopRecording() {
      if (recording) {
      recording = false;
      output.flush(); // Writes the remaining data to the file
      output.close(); // Finishes the file
      }
}


PImage muscleMap;
ArrayList muscleNames;
int muscleIndex=0;
int musclePoint=0;
int activeMuscle=-1;

ArrayList Muscles;
public String getActiveMuscle() {
   if (activeMuscle == -1) return "Not Selected";
  else {
    Muscle m = (Muscle) Muscles.get(activeMuscle);
    return m.name;
  } 
}

public void setupMuscleMap() {
  muscleNames = new ArrayList();
  Muscles = new ArrayList();

  setupMuscleNames();
 // setupFont();
  muscleMap = loadImage("musclemap.jpeg");
  noStroke();
  background(0);
  float h, w, s;

  if (height< muscleMap.height) {
    h=height;
    s=height/muscleMap.height;
    w=muscleMap.width*s;
  } 
  else {
    h=muscleMap.height;
    s=muscleMap.height/height;
    w=width*s;
  }

  muscleMap.resize(PApplet.parseInt(w), PApplet.parseInt(h));

  setupMusclePoints();
}

public void user() {
  println("select points for: " + muscleNames.get(muscleIndex));
}

public void drawMuscleMap() {
  muscleFont = createFont("Free Sans", 20);
  background(0);
  fill(255,0,0);
  image(muscleMap, 0, 0);
  //ellipse(mouseX, mouseY, 5, 5);
  snapToMuscle();
  drawNotes();
}


public void listMuscleNames() {
  for (int i =0; i < muscleNames.size(); i++) 
    println( muscleNames.get(i));
}

class Muscle {
  int x0, y0, x1, y1;
  String name;
  Muscle (String s, int xx0, int yy0, int xx1, int yy1) {
    x0=xx0;
    y0=yy0;
    x1=xx1;
    y1=yy1;
    name = s;
  }
}

public void snapToMuscle() {
//  println(Muscles.size());
  for (int i=0; i< Muscles.size(); i++) {
  //  print("i => ");
      Muscle m = (Muscle) Muscles.get(i);
      
      if ((dist(m.x0, m.y0, mouseX, mouseY) < 3) || (dist(m.x1, m.y1, mouseX, mouseY) < 6)) {
        println("m: " + m.name);
          ellipse(m.x0,m.y0, 6,6);
          ellipse(m.x1,m.y1, 6,6);
          text(m.name, 4*width/7, 20);
      }
  }  
}

public void drawNotes() {
  
}

public void mapFoucedMousePressed() {
  //println( mouseX + ", " + mouseY );
    for (int i=0; i< Muscles.size(); i++) {
  //  print("i => ");
      Muscle m = (Muscle) Muscles.get(i);
      
      if ((dist(m.x0, m.y0, mouseX, mouseY) < 3) || (dist(m.x1, m.y1, mouseX, mouseY) < 6)) {
      //  println("m: " + m.name);
          //text(m.name, 4*width/7, 20);
          activeMuscle = i;
          focus = 0;
          return;
      }
      //activeMuscle=-1;
     // focus = 0;
  } 

/*
  if (musclePoint == 1) {
    println(", " + mouseX + ", " + mouseY + "));");
    musclePoint = 0;
    muscleIndex ++;
    user();
  }
  else {
    musclePoint = 1; 
    print("Muscles.add( new Muscle(\"" + muscleNames.get(muscleIndex) + "\", " + mouseX + ", " + mouseY );
  }
  */
}

/*
void setupFont() {
  muscleFont = createFont("Free Sans", 20);
  textFont(muscleFont);
}
*/

public void setupMusclePoints() {
  Muscles.add( new Muscle("M. sternocieldo mastoideus", 81, 95, 81, 102));
  Muscles.add( new Muscle("M. deltoideus pars claviculars", 121, 130, 125, 136));
  Muscles.add( new Muscle("M. pectoralis major pars claviculars", 98, 122, 105, 126));
  Muscles.add( new Muscle("M. pectoralis major pars sternocostslis", 88, 145, 95, 145));
  Muscles.add( new Muscle("M. pectoralis major pars abdominials", 105, 157, 111, 153));
  Muscles.add( new Muscle("M. biceps brachii", 131, 167, 134, 177));
  Muscles.add( new Muscle("M. brachioradialis", 15, 216, 16, 223));
  Muscles.add( new Muscle("M. obliquus extemus", 110, 219, 106, 228));
  Muscles.add( new Muscle("M. rectus abdominis upper", 68, 185, 67, 191));
  Muscles.add( new Muscle("M. rectus abdominis lower", 64, 223, 64, 232));
  Muscles.add( new Muscle("M. obliguus internus abdominis", 55, 247, 61, 254));
  Muscles.add( new Muscle("Extensor group digitorm", 260, 52, 261, 60));
  Muscles.add( new Muscle("Extensor group carpi ulnaris", 274, 54, 271, 61));
  Muscles.add( new Muscle("Flexor group radial", 276, 70, 275, 75));
  Muscles.add( new Muscle("Flexor group ulnar", 277, 88, 275, 96));
  Muscles.add( new Muscle("Adductor group longus", 286, 176, 286, 183));
  Muscles.add( new Muscle("Adductor group brevis", 280, 173, 279, 178));
  Muscles.add( new Muscle("M. rectus femoris", 273, 186, 273, 194));
  Muscles.add( new Muscle("M. vastus femoris", 267, 199, 268, 206));
  Muscles.add( new Muscle("M. vastus medialis", 285, 215, 283, 223));
  Muscles.add( new Muscle("M. semitendinosus membranosus", 269, 283, 269, 290));
  Muscles.add( new Muscle("M. biceps femoris", 276, 288, 277, 294));
  Muscles.add( new Muscle("M. trapezius pars descendens", 98, 396, 103, 402));
  Muscles.add( new Muscle("M. infraspinatus", 100, 432, 105, 432));
  Muscles.add( new Muscle("M. deltoideus pars acromialis", 140, 433, 142, 439));
  Muscles.add( new Muscle("M. deltoideus pars spinalis", 121, 434, 124, 439));
  Muscles.add( new Muscle("M. trapezuis rhomboideus", 81, 438, 87, 438));
  Muscles.add( new Muscle("M. triceps brachii caput longum", 127, 467, 127, 473));
  Muscles.add( new Muscle("M. triceps brachii caput laterale", 136, 474, 138, 480));
  Muscles.add( new Muscle("M. latissimus dorsi", 104, 488, 108, 485));
  Muscles.add( new Muscle("M. erector spinae", 79, 501, 81, 545));
  Muscles.add( new Muscle("M. multifidus", 78, 565, 78, 571));
  Muscles.add( new Muscle("M. glutaeus medius", 109, 567, 113, 567));
  Muscles.add( new Muscle("M. glutaeus maximus", 91, 596, 93, 601));
  Muscles.add( new Muscle("M. tibialis anterior", 273, 411, 274, 417));
  Muscles.add( new Muscle("M. peronaeus", 272, 445, 272, 452));
  Muscles.add( new Muscle("M. gastrocnemius lateralis", 282, 563, 283, 569));
  Muscles.add( new Muscle("M. gastrocnemius medialis", 271, 566, 271, 571));
  Muscles.add( new Muscle("M. soleus", 270, 592, 271, 597));
}

public void setupMuscleNames()
{
  
  muscleNames.add(new String("M. sternocieldo mastoideus"));
  muscleNames.add(new String("M. deltoideus pars claviculars"));
  muscleNames.add(new String("M. pectoralis major pars claviculars"));
  muscleNames.add(new String("M. pectoralis major pars sternocostslis"));
  muscleNames.add(new String("M. pectoralis major pars abdominials"));
  muscleNames.add(new String("M. biceps brachii"));
  muscleNames.add(new String("M. brachioradialis"));
  muscleNames.add(new String("M. obliquus extemus"));
  muscleNames.add(new String("M. rectus abdominis upper"));
  muscleNames.add(new String("M. rectus abdominis lower"));
  muscleNames.add(new String("M. obliguus internus abdominis"));

  muscleNames.add(new String("Extensor group digitorm"));
  muscleNames.add(new String("Extensor group carpi ulnaris"));
  muscleNames.add(new String("Flexor group radial"));
  muscleNames.add(new String("Flexor group ulnar"));
  muscleNames.add(new String("Adductor group longus"));
  muscleNames.add(new String("Adductor group brevis"));
  muscleNames.add(new String("M. rectus femoris"));
  muscleNames.add(new String("M. vastus femoris"));
  muscleNames.add(new String("M. vastus medialis"));
  muscleNames.add(new String("M. semitendinosus membranosus"));
  muscleNames.add(new String("M. biceps femoris"));

  muscleNames.add(new String("M. trapezius pars descendens"));
  muscleNames.add(new String("M. infraspinatus"));
  muscleNames.add(new String("M. deltoideus pars acromialis"));
  muscleNames.add(new String("M. deltoideus pars spinalis"));
  muscleNames.add(new String("M. trapezuis rhomboideus")); 
  muscleNames.add(new String("M. triceps brachii caput longum"));
  muscleNames.add(new String("M. triceps brachii caput laterale"));
  muscleNames.add(new String("M. latissimus dorsi"));
  muscleNames.add(new String("M. erector spinae"));
  muscleNames.add(new String("M. multifidus"));
  muscleNames.add(new String("M. glutaeus medius"));
  muscleNames.add(new String("M. glutaeus maximus"));

  muscleNames.add(new String("M. tibialis anterior"));
  muscleNames.add(new String("M. peronaeus"));

  muscleNames.add(new String("M. gastrocnemius lateralis"));
  muscleNames.add(new String("M. gastrocnemius medialis"));
  muscleNames.add(new String("M. soleus"));
}

// automatically establish serial port

//do a context change to allow connection
public boolean isSerialConnected() {
  if (serialConnected) return true;
  return false;
}

public boolean establishSerialConnection() {
  //cycle through serial ports testing each one
  String ports[] = Serial.list(); 
  println("Found: " + ports.length + " ports."); 
  println(ports);

  for (int i=0; i < ports.length; i++) {
    println("Testing port: " + ports[i]);
    myPort = new Serial(this, ports[i], 115200);
    myPort.bufferUntil('\n');
    myPort.clear();

    myDelay(2000);
    serialSend("biofeedback v1?");

    for (int j =0; j< 3; j++) { //retry 3 times
      myDelay(1000);
      if (isSerialConnected()) {//this is a bit dodgy
        return true;
      }
    }
    myPort.stop();
  }
  println("Failed to establish serial connection.");
  return false;
}

public void serialSend(String s) {
  println("serialSend: " + s);
  for (int i=0; i< s.length(); i++)
    myPort.write(s.charAt(i));
}


public void disconnectedSerialEvent(Serial myPort) {
  String s;
  s = myPort.readStringUntil('\n');
  if (s != null) {
    println("Got: " + s);
    if ( s.startsWith("biofeedback v1") )
      serialConnected = true;
      myPort.bufferUntil('\n');
  }
}

public void myDelay(int m) {  //delay() is broken in 1.5.1 release
  int t0 = millis();
  int tn = t0 + m;

  while (tn-millis () > 0) {
    delay(1); //use it if it works
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "biofeedback_host" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
